const bookDB = require('../model/Book');
const book = {}
book.bookservice = (bookingObj) => {
    return bookDB.book(bookingObj).then((data)=>{
            if(data){return data}
            else{
                let err = new Error("Booking unsuccesful")
                err.status = 406
                throw err}
    }).catch ((e)=>{
            let err = new Error("Booking unsuccesful")
            err.status = 406
            throw err
    })
}
book.cancelService=(bookingId)=>{
    return bookDB.cancel(bookingId).then((data)=>{
        if(data){return data}
        else{

       let err = new Error("cancel unsuccessful")
                err.status = 406
                throw err}
    }).catch ((e)=>{
            let err = new Error("cancel unsuccesful")
            err.status = 406
            throw err
    })
}

module.exports = book