const db = require('../model/Package');

let packageService = {}

packageService.getdeals=()=>{
    return db.getdeals().then((hotdeals)=>{
        return hotdeals;
    }).catch(err => next(err))
}
packageService.getdestinations=(continent)=>{
    return db.getdestinations(continent).then((destinations)=>{
        if(destinations)return destinations;
        else{
            let e= new Error("Sorry! we do not operation on the given location");
            e.status =406;
            throw e;
        }
    }).catch(err => next(err))
}

module.exports = packageService;

