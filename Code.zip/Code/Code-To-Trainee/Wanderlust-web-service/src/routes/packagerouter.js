const express = require('express');
const router = express.Router();
const package = require('../service/package')
//router to hotdeals
router.get('/hotDeals',function (req,res,next){
    return package.getdeals().then((hotdeals) =>{
        res.json(hotdeals);
    }).catch(err => next(err));
})
 router.get('/destinations/:continent',function(req,res,next){
     return package.getdestinations(req.params.continent).then((destinations)=>{
         res.json(destinations);
     }).catch(err => next(err))
 })

module.exports = router;
