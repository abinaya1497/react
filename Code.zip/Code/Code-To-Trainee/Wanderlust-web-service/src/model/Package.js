const dBModel = require("../utilities/connections");

let packageDb = {};

packageDb.getdeals = () => {
    return dBModel.getHotdealsCollection().then((model) => {
        return model.find().then((hotdeals) => {
            return hotdeals
        })
        .catch(err => next(err))
    })
}
packageDb.getdestinations = (continent) =>{
    return dBModel.getDestinationCollection().then((model) => {
        let cont = new RegExp(["^",continent,"$"].join(""),"i")
        let name = new RegExp([continent].join(""),"i")
        return model.find({$or:[{continent : cont},{name:name}]}).then((destinations) => {
                return dBModel.getHotdealsCollection().then((model1)=>{
                    return model1.find({$or:[{continent : cont},{name:name}]}).then((destination) => {
                        let destin =destination.concat(destinations);
                        console.log(destination);
                        
                        if(destination) {return destin}
                        else{
                            return null
                        }
                })
            })
        
        })
        .catch((err => next(err)))
    })
}

module.exports = packageDb