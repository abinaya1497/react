const userDetails = require('./beanClasses/bookings');
const connection = require("../utilities/connections");
const bookDB ={}

bookDB.generateId = () => {
    return connection.getBookingCollection().then((collection) =>{
        return collection.distinct("bookingId").then((ids) => {
            let UIds =[];
            ids.forEach((id) => {
                let i = id.substr(1,)
                UIds.push(Number(i))
            } )
            let uId = Math.max(...UIds);
            return uId+1;
        })
    })}
bookDB.book =(bookingObj) =>{
    return connection.getBookingCollection().then ((collection)=>{
        let bookingObject ={}
        bookingObject= bookingObj;        
        return bookDB.generateId().then((id)=>{
            bookingObject.bookingId="B"+id;
            console.log(bookingObject);
            return collection.insertMany(bookingObject).then((data) =>{
                if(data){
                return connection.getUserCollection().then((user)=>{
                    return user.updateOne({userId:bookingObject.userId},{$push:{bookings:bookingObject.bookingId}}).then((dat)=>{
                        if(dat){
                            return "Congratulations! Your Booking has confirmed";
                        }
                        else{
                            return null;
                        }
                    })
                })
            }else{
                return null;
            }
                                        
            })
        });
        
    })
}
bookDB.cancel =(bookingId)=>{
    return connection.getBookingCollection().then((collection)=>{
        return collection.find({bookingId:bookingId},{_id:0,userId:1}).then((userId)=>{
            return collection.deleteOne({bookingId:bookingId}).then((data)=>{
                if(data){
                    return connection.getUserCollection().then((model)=>{
                        return model.update({userId:userId[0].userId},{$pull:{bookings:{$in:bookingId}}}).then((data)=>{
                            if(data){return data}
                            else{
                                return null;
                            }
                        })
                    })
                }
                else{
                    return null;
                }
            })
        })
        
    })
}
module.exports=bookDB