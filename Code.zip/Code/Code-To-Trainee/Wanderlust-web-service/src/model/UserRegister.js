const connection = require("../utilities/connections")
const usersDB ={}
usersDB.checkUser =(contactNo) =>{
    return connection.getUserCollection().them((collection) =>{
        return collection.findOne({"contactNo": contactNo }).then((customerContact) =>{
            if(customerContact) {
                return new userDetails(customerContact);
            }
            else return null;
        })
    })
}

usersDB.generateId= () =>{
    return connection.getUserCollection().then((collection) =>{
        return collection.distinct("userId").then((id) =>{
            let UId = []
            id.foreach((userid) =>{
                let val =userid.substr(1,)
                UId.push(Number(val));
            })
            let uid = Math.max(...UId);
            return uid+1;
        })
    })
}

usersDB.toRegister = (name, emailId, contactno, password) => {
    return connection.getUserCollection().then((collection) =>{
        let userData ={};
        userData.name=name;
        userData.emailId=emailId;
        userData.contactno=contactno;
        userData.password=password;
        userData.booking = [];
        return usersDB.generateId().then((id) =>{
            userData.userid = "U" + id;
            console.log(userData);
            return collection.insertMany(userData).then((data) =>{
                if(data){
                    return "Sucessfully Registered"
                }
                else{
                    return "Registration failed! please try again"
                }
            })
        })
    })
}


module.exports = usersDB;
