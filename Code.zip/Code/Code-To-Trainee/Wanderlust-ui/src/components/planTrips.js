import React, { Component } from "react"
import axios from "axios"
import { ProgressSpinner } from "primereact/progressspinner"
import { Growl } from "primereact/growl"
import { Link } from "react-router-dom"
import { Dialog } from "primereact/dialog"
import { Button } from "primereact/button"
import "bootstrap/dist/css/bootstrap.css"
import "../index.css"


class ViewBookings extends Component {

    constructor(props) {
        super(props);
        this.state = {
            BookingsObj: [],
            errorMessage: "",
            show: true,
            dialog_visible: false,
            name:"",
            object:"",
            successMessage:""
        }
    }

    componentDidMount() {
        this.getBookings()
    }

    deletebookings = (bId) => {
        axios.delete("http://localhost:4000/book/cancelBooking/" + bId).then((response) => {
            this.setState({ successMessage: response.data.message, errorMessage: "" })
            this.showInfo()
            this.getBookings()
        }).catch(err => {
            this.setState({ errorMessage: err.message, successMessage: "" })
            this.getBookings()
        })
    }

    getBookings = () => {
        let userId = sessionStorage.getItem("userId")
        axios.get("http://localhost:4000/book/getBooking/" + userId).then((response) => {
            this.setState({ BookingsObj: response.data, errorMessage: "", show: false })
        }).catch(err => {
            this.setState({ errorMessage: err.response.data.message, BookingsObj: [], show: false })
        })
    }
    delete = (bId) => {
        this.setState({ dialog_visible: false })
        this.deletebookings(bId)
    }
    onHide = () => {
        this.setState({ dialog_visible: false })
    }
    onClick = (obj) => {
        this.setState({ dialog_visible: true })
        this.setState({ object: obj })
    }

    showInfo = () => {
        this.growl.show({ severity: "info", summary: "Info Message", detail: this.state.successMessage })
    }

    render() {
        return (
            <React.Fragment>
                <section>
                    <div>
                        <div>
                            <Growl ref={(el) => this.growl = el} style={{ margin: "40px 500px" }} />
                            {this.showInfo}
                            {this.state.show ? (<ProgressSpinner></ProgressSpinner>) :
                                (this.state.BookingsObj.length !== 0 ? (
                                    <div>
                                        {
                                            this.state.BookingsObj.map((value, index) => {
                                                return (
                                                    <div key={index}>
                                                        <div id="viewBookingPage" className="viewBookings" value={value.bookingId}>
                                                            <div className="col-md-8 offset-2">
                                                                <div className="card">
                                                                    <div className="card-header" align="left">Booking Id: <span>{value.bookingId}</span></div>
                                                                    <div className="card-body">
                                                                        <div className="row">
                                                                            <span style={{ marginLeft: "2%" }}><h4 style={{ fontWeight: "bold" }}>{value.desitinationName}</h4></span>
                                                                            <br></br><br></br>
                                                                            <div className="col-md-8" align="left">
                                                                                Trip starts on :{new Date(value.checkInDate).toLocaleDateString("en-us", { month: "long", day: "numeric", year: "numeric" })}<br></br>
                                                                                Trip ends on :{new Date(value.checkOutDate).toLocaleDateString("en-us", { month: "long", day: "numeric", year: "numeric" })}<br></br>
                                                                                Travellers:{value.noOfPerson}
                                                                            </div>
                                                                            <div className="col-md-4" align="left">
                                                                                Fare Details<br></br>
                                                                                ${value.totalCharges}<br></br>

                                                                                <Link to="#" onClick={() => this.onClick(value)}>Claim Refund</Link>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="card-footer"></div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                            </div>
                                                )
                                            })
                                        }
                                        </div>):
                                        (<div className="offset-2">
                                            <h2 className="text-center">Sorry you dont planned any trip with us yet!</h2><br></br>
                                            <h2 className="text-center"> <a href="/packages" className="btn btn-success">Click here to checkout our hot deals </a></h2>
                                            <br></br>
                                        </div>)

                            )}

                        </div>
                     </div>
                </section>
                <br></br>
                <Dialog header="Confirm Cancellation" footer={(
                    <div>
                        <Button label="Confirm Cancellation" icon="pi pi-check" className="p-button-danger" onClick={()=>this.delete(this.state.object.bookingId)}></Button>
                        <Button label="Back" icon="pi pi-times" className="p-button-info" onClick={this.onHide}></Button>
                    </div>

                )} visible={this.state.dialog_visible} style={{width:"50vw"}} modal={true} onHide={this.onHide}>
                    <span className="text-danger">Are you sure you want to cancel your trip to {this.state.object.desitinationName}?</span>
                    <div align="text-center">
                        Trip start date:{new Date(this.state.object.checkInDate).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}
                        Trip end date:{new Date(this.state.object.checkOutDate).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}
                        Refund Amount:${this.state.object.totalCharges}
                    </div>
                </Dialog>
            </React.Fragment>
        )
    }

}
export default ViewBookings;
