import React, { Component } from "react"
import axios from "axios"
import { InputText } from "primereact/inputtext"
import { Link } from "react-router-dom"
import { backendUrlUser } from "../BackendURL"
import "bootstrap/dist/css/bootstrap.css"
import "../index.css"

class Register extends Component {
    constructor(props) {
        super(props)
        this.state = {
            registerForm: {
                name: "",
                emailId: "",
                contactNo: "",
                password: ""
            },
            registerFormErrorMessage: {
                name: "",
                emailId: "",
                contactNo: "",
                password: ""
            },
            registerFormValid: {
                name: false,
                emailId: false,
                contactNo: false,
                password: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: "",
            register: false,
            loadHome: false,
            logstat: false,
            userId: ""
        }
    }
    handleClick = () => {
        this.setState({ register: true })
    }

    handleChange = (event) => {
        let value = event.target.value
        let name = event.target.name
        let { registerForm } = this.state
        this.setState({
            registerForm: { ...registerForm, [name]: value }
        })
        this.validateField(name, value)
    }
    register = () => {
        let { registerForm } = this.state
        axios.post(backendUrlUser + "/register", registerForm)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" })

            }).catch(error => {
                this.setState({ errorMessage: error.response.data.message, successMessage: "" })
                //this.errorMessage = error.message;
            })

    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.register();
        this.setState({ logstat: true })
    }

    validateField = (fieldname, value) => {
        let fieldValidationError = this.state.registerFormErrorMessage
        let formValid = this.state.registerFormValid
        switch (fieldname) {
            case "name":
                let nameRegex = /^[A-Z][A-Z ]*[A-Z]$/i
                if (value === "") {
                    fieldValidationError.name = "Please enter your name"
                    formValid.name = false
                } else if (!value.match(nameRegex)) {
                    fieldValidationError.name = "Please enter a valid name"
                    formValid.name = false
                } else {
                    fieldValidationError.name = ""
                    formValid.name = true
                }
                break;
            case "emailId":
                let emailRegex = /^[A-z]{1,}[@][A-z]{1,}\.[A-Za-z]{2,3}$/
                if (value === "") {
                    fieldValidationError.emailId = "Please enter your email Id"
                    formValid.emailId = false
                } else if (!value.match(emailRegex)) {
                    fieldValidationError.emailId = "Please enter a valid email Id"
                    formValid.emailId = false
                } else {
                    fieldValidationError.emailId = ""
                    formValid.emailId = true
                }
                break;
            case "contactNo":
                let contactRegex = /^[6-9][0-9]{9}$/
                if (value === "") {
                    fieldValidationError.contactNo = "Please enter your Contact Number"
                    formValid.contactNo = false
                } else if (!value.match(contactRegex)) {
                    fieldValidationError.contactNo = "Please enter a valid Contact Number"
                    formValid.contactNo = false
                } else {
                    fieldValidationError.contactNo = ""
                    formValid.contactNo = true
                }
                break;
            case "password":
                if (value === "") {
                    fieldValidationError.password = "Password is Mandatory"
                    formValid.password = false
                } else if (!(value.match(/[A-Z]/) && value.match(/[a-z]/) && value.match(/[0-9]/) && value.match(/[!@#$%^&]*/) && value.length >= 7 && value.length <= 20)) {
                    fieldValidationError.password = "Please enter strong password"
                    formValid.password = false
                } else {
                    fieldValidationError.password = ""
                    formValid.password = true
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.name && formValid.emailId && formValid.contactNo && formValid.password
        this.setState({
            registerFormErrorMessage: fieldValidationError,
            registerFormValid: formValid,
            successMessage: ""
        })
    }


    render() {
        return (

            <div>
                <section id="registerPage" className="registerSection">
                    <div className="container-fluid">
                        <div className="'row">
                            <div className="col-md-4 offset-4 text-left">
                                {(!(this.state.errorMessage || this.state.successMessage))
                                    ?
                                    <div>
                                        <h2 className="text-left animate-bottom">Join Us</h2><br></br>
                                        <form className="form" onSubmit={this.handleSubmit}>
                                            <div className="form-group">
                                                <label htmlFor="name">Name<span className="text-danger">*</span></label>
                                                <div className="form-group p-float-label">
                                                    <InputText type="text" value={this.state.registerForm.name} onChange={this.handleChange}
                                                        id="name"
                                                        name="name"
                                                        className="form-control"/>
                                                </div>
                                                <span name="nameError" className="text-danger">{this.state.registerFormErrorMessage.name}</span>
                                                <br></br>

                                                <label htmlFor="email">Email Id<span className="text-danger">*</span></label>
                                                <div className="form-group p-float-label">
                                                    <InputText type="text" value={this.state.registerForm.emailId} onChange={this.handleChange}
                                                        id="emailId"
                                                        name="emailId"
                                                        className="form-control"/>
                                                </div>
                                                <span name="emailError" className="text-danger">{this.state.registerFormErrorMessage.emailId}</span>
                                                <br></br>

                                                <label htmlFor="contactno">Contact Number<span className="text-danger">*</span></label>
                                                <div className="form-group p-float-label">
                                                    <InputText type="text" value={this.state.registerForm.contactNo} onChange={this.handleChange}
                                                        id="contactNo"
                                                        name="contactNo"
                                                        className="form-control"
                                                    />

                                                </div>
                                                <span name="contactnoError" className="text-danger">{this.state.registerFormErrorMessage.contactNo}</span>
                                                <br></br>
                                                <label htmlFor="password">Password<span className="text-danger">*</span></label>
                                                <div className="form-group p-label-float">
                                                    <InputText type="password" value={this.state.registerForm.password} onChange={this.handleChange}
                                                        id="password"
                                                        name="password"
                                                        placeholder="Password"
                                                        className="form-control"/>
                                                </div>
                                                <span name="passwordError" className="text-danger">{this.state.registerFormErrorMessage.password}</span>
                                                <br></br>
                                                <span className="text-danger">*</span>All field are Mandatory
                                                <br></br>
                                            </div>
                                            <button type="submit" disabled={!this.state.registerFormValid.buttonActive} className="btn btn-primary  form-control"
                                            name="registerbtn" onClick={this.handleClick}>Register</button>
                                        </form>
                                        
                                    </div>
                                    :
                                    (this.state.errorMessage ?
                                        <div>
                                           <h3 > <div className="text-danger">{this.state.errorMessage}</div></h3>
                                            <h3 ><div><a href="http://localhost:3000/register">Click Here to Register again.</a></div></h3>
                                        </div>
                                        :
                                        <div>
                                            <h3 className="text-success">{this.state.successMessage}</h3>
                                            <h3 ><Link href="http://localhost:3000/login">Click Here to login.</Link></h3>
                                        </div>
                                    )
                                }
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        )
    }
}
export default Register;