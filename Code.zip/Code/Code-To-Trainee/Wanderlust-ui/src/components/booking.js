import React, { Component } from "react"
import { Fieldset } from "primereact/inputswitch"
import { InputSwitch } from "primereact/inputswitch"
import { Link, Redirect } from "react-router-dom"
import Axios from "axios"
import { backendUrlBooking } from "../BackendURL"

class Bookings extends Component {
    constructor(props) {
        super(props);
        this.state = {
            bookingForm: {
                noOfPersons: this.props.location.state.noOfPersons,
                date: this.props.location.state.date,
                flights: this.props.location.state.flights
            },
            bookingFormErrorMessage: {
                noOfPersons:"",
                date: ""
            },
            bookingFormValid: {
                noOfPersons: false,
                date: false,
                buttonActive: false
            },
            firstDay: this.props.location.state.deal.details.itinerary.dayWiseDetails.firstDay,
            otherDay: this.props.location.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing,
            lastDay: this.props.location.state.deal.details.itinerary.dayWiseDetails.lastDay,
            logstat: false,
            deal: this.props.location.state.deal,
            checkOutDate: "",
            totalCharges: this.props.location.state.totalCharges,
            successMessage: "",
            errorMessage: "",
            show: true,
            packagePage: false,
            hotDealsPage: false,
        }
    }
    componentWillMount = () => {
        this.setState({ checkOutDate: this.props.location.state.checkOutDate })
        this.calculateCharges()
    }
    validateField = (fieldname, value) => {
        let fieldValidationErrors = this.state.bookingFormErrorMessage;
        let formValid = this.state.bookingFormValid
        let bookingForm = this.state.bookingForm

        switch (fieldname) {
            case "noOfPersons":
                if (value === "") {
                    fieldValidationErrors.noOfPersons = "This Field can't be empty";
                    formValid.noOfPersons = false
                } else if (value < 1) {
                    fieldValidationErrors.noOfPersons = "No of person can't be less than 1";
                    formValid.noOfPersons = false
                } else if (value > 5) {
                    fieldValidationErrors.noOfPersons = "No of person can't be more than 5";
                    formValid.noOfPersons = false
                }
                else {
                    fieldValidationErrors.noOfPersons = "";
                    formValid.noOfPersons = true
                    bookingForm.noOfPersons = value
                }
                break;
            case "date":
                if (value === "") {
                    fieldValidationErrors.date = "This Field can't be empty";
                    formValid.date = false
                } else {
                    let checkInDate = new Date(value)
                    let today = new Date()
                    if (today.getTime() > checkInDate.getTime()) {

                        fieldValidationErrors.date = "Check-in date cannot be a past data!";
                        formValid.date = false
                    }
                    else {
                        fieldValidationErrors.date = "";
                        formValid.date = true
                        bookingForm.date = value
                    }
                }
                break;
            default:
                break;
        }

    }
    handleChange = (event) => {
        const target = event.target
        const name = target.name;
        if (target.checked) {
            var value = target.checked
        } else {
            value = target.value
        }
        const { bookingForm } = this.state;
        this.setState({
            bookingForm: { ...bookingForm, [name]: value }
        }, () => {
            this.validateField(name, value);
            this.calculateCharges()
        })
    }
    calculateCharges = () => {
        this.setState({ totalCharges: 0 })
        let oneDay = 24 * 60 * 60 * 1000;
        let checkInDate = new Date(this.state.bookingForm.date);
        let checkOutDateinMs = Math.round(Math.abs((checkInDate.getTime() + (this.state.deal.noOfNights) * oneDay)))
        let finalCheckOutDate = new Date(checkOutDateinMs)
        let value = this.state.bookingForm.flights
        this.setState({ checkOutDate: finalCheckOutDate })
        if (value === true) {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.deal.chargesPerPerson + this.state.deal.flightCharges;
            this.setState({ totalCharges: totalCost })
        } else {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.deal.chargesPerPerson;
            this.setState({ totalCharges: totalCost })
        }
    }
    handleSubmit = (event) => {
        event.preventDefault();
        let form = {
            noOfPersons:this.state.bookingForm.noOfPersons,
            checkInDate: this.state.bookingForm.date,
            checkOutDate: this.state.checkOutDate,
            destinationName: this.state.deal.name,
            totalCharges: this.state.totalCharges
        }
        let userId = sessionStorage.getItem("userId")

        Axios.post(backendUrlBooking + "/" + userId + "/" + this.state.deal.destinationId, form)
            .then((response) => {
                this.setState({ successMessage: response.data.message, errorMessage: "", show: false })
            }).catch((error) => {
                this.setState({ errorMessage: error.response.data.message, successMessage: "", show: false })
            })
    }
    render() {
        return (
            <React.Fragment>
                {!this.state.show ? ((this.state.successMessage) ?
                    (<section>
                        <div className="card">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-8 offset-2 text-center">
                                        <br></br>
                                        <h2>Booking Confirmed!!</h2>
                                        <br></br>
                                        <h3 className="text-success">{this.state.successMessage}</h3><br></br>
                                        <br></br>
                                        <h3 className="">Trip start on: {new Date(this.state.bookingForm.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</h3>
                                        <h3 className="">Trip end on: {new Date(this.state.checkOutDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</h3>
                                        <h4 className="text-info"><Link to="/viewBookings">Click here to view your Bookings</Link></h4><br></br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>) :
                    (
                        <div className="card">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-8 offset-2 text-center">
                                        <br></br>
                                        <h3 className="text-danger">{this.state.errorMessage}</h3><br></br>
                                        <h4 className="text-info"><a href={"/book/" + this.state.deal.destinationId}>Click here to change your booking </a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )) :
                    <section>
                        <br></br>
                        <br></br>
                        <div className="row">
                            <div className="col-md-6 offser-1">
                                <div className="text-left">
                                    <h1>{this.state.deal.name}</h1>
                                    <Fieldset legend="Overview" toggleable={true} collapsed={true}>
                                        {this.state.deal.details.about}
                                    </Fieldset>
                                    <Fieldset legend="Package Inclusions" toggleable={true} collapsed={true}>
                                        <ul>
                                            {this.state.deal.details.itinerary.packageInclusion.map(i => {
                                                return (<li key={i}>{i}</li>)
                                            })}
                                        </ul>
                                    </Fieldset>
                                    <Fieldset legend="Itinerary" toggleable={true} collapsed={true}>
                                        <h3>Day Wise Itenerary</h3>
                                        <h5>Day 1</h5>
                                        <h6>{this.state.firstDay}</h6>
                                        {this.state.otherDay.map(day => {
                                            return <React.Fragment key={day}><h5> Day {this.state.otherDay.indexOf(day) + 2}</h5>
                                                <h6>{day}</h6>
                                            </React.Fragment>
                                        })}
                                        <h5>Day {this.state.otherDay.length + 2}</h5>
                                        <h6>{this.state.lastDay}</h6>
                                        <div className="text-danger">
                                            **this Itenerary is just a suggesstion
                                        <a href="">Contact us</a> for more details.
                                    </div>
                                    </Fieldset>
                                    <br></br>
                                </div>
                            </div>
                            <div className="col-md-4 offset-0.5">
                                <form className="text-left" onSubmit={this.handleSubmit}>
                                    <div className="card">
                                        <div className="container">
                                            <br></br>
                                            <div className="form-group">
                                                <label htmlFor="noOfPersons">Number of Travellers:</label>
                                                <input type="number"
                                                    id="noOfPersons"
                                                    className="form-control"
                                                    name="noOfPersons"
                                                    placeholder="min-1 max-5"
                                                    value={this.state.bookingForm.noOfPersons}
                                                    onChange={this.handleChange} />
                                                {this.state.bookingFormErrorMessage.noOfPersons ? <span classname="text-danger">{this.state.bookingFormErrorMessage.noOfPersons}</span> : null}
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="date">Trip start date:</label>
                                                <input type="date"
                                                    id="date"
                                                    className="form-control"
                                                    name="date"
                                                    value={this.state.bookingForm.date}
                                                    onChange={this.handleChange} />
                                                {this.state.bookingFormErrorMessage.date ? <span classname="text-danger">{this.state.bookingFormErrorMessage.date}</span> : null}
                                            </div>
                                            <div className="form-group">
                                                <label>Include Flights</label>&nbsp;
                                            <InputSwitch name="flight" id="flight" checked={this.state.bookingForm.flights} onChange={this.handleChange} />
                                            </div>
                                            <h6>Your trip end on :{new Date(this.state.checkOutDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</h6>
                                            <h4 className="">You Pay:${this.setState.totalCharges}</h4>
                                            <div>
                                                <button type="submit" className="btn btn-primary"> Confirm Booking </button>&nbsp
                                            <button type="button" onClick={() => {
                                                    if (this.state.deal.destinationId.match(/^D/)) {
                                                        this.setState({ packagePage: true, hotDealsPage: false })
                                                    }
                                                    else {
                                                        this.setState({ packagePage: false, hotDealsPage: true })
                                                    }
                                                }} className="btn btn-primary">Go Back</button>

                                            </div>
                                            <br></br>
                                        </div>
                                        <br></br>
                                        {this.state.packagePage ? (<Redirect to={"/packages/destinations/" + this.state.deal.continent}></Redirect>) : null}
                                        {this.state.hotDealsPage ? (<Redirect to="/packages"></Redirect>) : null}
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
    }

            </React.Fragment>)
    }
}
export default Bookings;



























