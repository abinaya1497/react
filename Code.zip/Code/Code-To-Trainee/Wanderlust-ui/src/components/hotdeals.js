import React, { Component } from "react";
import axios from "axios";
import {backendUrlUser,backendUrlPackage,backendUrlBooking} from '../BackendURL';
import "bootstrap/dist/css/bootstrap.css"
import "../index.css"
import { ProgressSpinner } from "primereact/progressspinner"
import { Sidebar } from "primereact/sidebar"
import { TabView, TabPanel } from "primereact/tabview"
import { InputSwitch } from "primereact/inputswitch"
import { Link, Redirect } from "react-router-dom"


class HotDeals extends Component {
    constructor(props) {
        super(props);
        this.state = {
            bookingForm: {
                noOfPerson: 1,
                date:"",
                flight:false
            },
            bookingFormErrorMessage: {
                noOfPerson: "",
                date: ""
            },
            bookingFormValid: {
                noOfPerson: false,
                date: false,
                buttonActive: false
            },
            hotDeals: [],
            errorMessage: "",
            loadBook: false,
            deal: "",
            showItinerary: false,
            checkOutDate: new Date(),
            totalCharges: "",
            index: "",
            bookingPage: false,
            dealId: "",
            show: true
        }
    }
    validateField = (fieldname, value) => {
        let fieldValidationError = this.state.bookingFormErrorMessage
        let formValid = this.state.bookingFormValid
        switch (fieldname) {
            case "noOfPerson":
                if (value === "") {
                    fieldValidationError.noOfPerson = "This field can't be empty"
                    formValid.noOfPerson = false
                } else if (value < 1) {
                    fieldValidationError.noOfPerson = "No of persons cant be less than 1."
                    formValid.noOfPerson = false
                }
                else if (value > 5) {
                    fieldValidationError.noOfPerson = "No of persons cant be more than 5."
                    formValid.noOfPerson = false
                } else {
                    fieldValidationError.noOfPerson = ""
                    formValid.noOfPerson = true
                }
                break;
            case "date":
                if (value === "") {
                    fieldValidationError.date = "This field can't be empty"
                    formValid.date = false
                }
                else {
                    let checkInDate = new Date(value)
                    let today = new Date()
                    if (today.getTime() > checkInDate.getTime()) {
                        fieldValidationError.date = "Check-in date cannot be past date! "
                        formValid.date = false
                    } else {
                        fieldValidationError.date = ""
                        formValid.date = true
                    }
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.noOfPerson && formValid.date;
        this.setState({
            loginFormErrorMessage: fieldValidationError,
            loginFormValid: formValid,
            successMessage: ""
        })
    }

    getHotDeals = () => {
        axios.get(backendUrlPackage + '/hotDeals')
            .then(response => {
                this.setState({ hotDeals: response.data, errorMessage: null })
            }).catch(error => {
                this.setState({ errorMessage: error.message, hotDeals: null })
            })
    }

    getitenary = (hotDeal) => {
        console.log(hotDeal);
        this.setState({ index: 0, deal: hotDeal, showItinerary: true })
    }

    loadBookingPage = (destId) => {
        console.log(destId);
        if (sessionStorage.getItem('userId')) {
            this.setState({ loadBook: true })
        }
        this.setState({ visibleRight: false })
        sessionStorage.setItem("dealId", destId)
        this.setState({ show: true, bookingPage: true, showItinerary: false, dealId: destId })
        this.setState({ redirect: true })
    }

    displayPackageInlusions = () => {
        const packageInclusions = this.state.deal.details.itinerary.packageInclusions
        if (this.state.deal) {
            return packageInclusions.map((pack, index) => (<li key={index}>{pack}</li>))
        } else {
            return null
        }
    }

    displayPackageHighlights = () => {
        let packageHighLightsArray = [];
        let firstElement = (
            <div key={0} className="text-left">
                
                <h5 c>Day 1</h5>
                {this.state.deal ? <div>{this.state.deal.details.itinerary.dayWiseDetails.firstDay}</div> : null}
            </div>
        );
        packageHighLightsArray.push(firstElement);
        if (this.state.deal) {
            this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.map((packageHighlight, index) => {
                let element = (
                    <div key={index + 1} className="text-left">
                        <h5>Day {this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.indexOf(packageHighlight) + 2}</h5>
                        <div>{packageHighlight}</div>
                    </div>
                );
                packageHighLightsArray.push(element)
            })
            let lastElement = (
                <div key={1} className="text-left">
                    <h5> Day {this.state.deal.details.itinerary.dayWiseDetails.restDaysSightSeeing.length+2}</h5> 
                    {this.state.deal.details.itinerary.dayWiseDetails.lastDay}
                    <div className="text-danger">
                        **this itinerary is just for suggestion.
                            <Link to="/"
                            onClick={
                                () => {
                                    window.scrollTo(5000, 5000)
                                }}>Contact us</Link> for more Details.

                        </div>
                </div>
            )
            packageHighLightsArray.push(lastElement)
            return packageHighLightsArray;
        }
        else {
            return null
        }
    }


    calculateCharges = () => {
        this.setState({ totalCharges: 0 });
        let oneDay = 24 * 60 * 60 * 1000;
        let checkInDate = new Date(this.state.bookingForm.date);
        let checkOutDateinMs = Math.round(Math.abs((checkInDate.getTime() + (this.state.deal.noOfNights) * oneDay)));
        let finalCheckOutDate = new Date(checkOutDateinMs);
        this.setState({ checkOutDate: finalCheckOutDate.toDateString() });
        if (this.state.bookingForm.flights) {
            let totalCost = (-(-this.state.bookingForm.noOfPerson)) * this.state.deal.chargesPerPerson + this.state.deal.flightCharges;
            this.setState({ totalCharges: totalCost });
        } else {
            let totalCost = (-(-this.state.bookingForm.noOfPerson)) * this.state.deal.chargesPerPerson;
            this.setState({ totalCharges: totalCost });
        }
    }



    handleChange = (event) => {
        const target = event.target;
        const name = target.name;
        if (target.checked) {
            var value = target.checked;
        } else {
            value = target.value;
        }
        const { bookingForm } = this.state;
        this.setState({
            bookingForm: { ...bookingForm, [name]: value }
        });

        this.validateField(name, value);

    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.calculateCharges();
    }


    openBooking = (selectedPackage) => {
        this.setState({ index: 2, deal: selectedPackage, showItinerary: true })
    }

    displayHotDeals = () => {
        let hotDealsArray = [];
        for (let hotDeal of this.state.hotDeals) {
            let name = hotDeal.imageUrl.split("/")[2]
            let element = (
                <div className="container card bg-light text-dark package-card" key={hotDeal.destinationId}>
                    <div className="card-body row">
                        <div className="col-md-4">
                            <div className="image">
                                <img className="package-image" src={require("../../public/assets/" + name)} alt="" />
                            </div>
                        </div>
                        <div className="col-md-5">
                            <div className="featured-text text-center text-lg-left card-border">
                                <h4>{hotDeal.name}</h4>
                                <div className="badge badge-info">{hotDeal.noOfNights}<em></em></div><br></br>
                                <span className="discount text-danger">{hotDeal.discount}% Instant Discount</span>
                                <p className="text-dark mb-0">{hotDeal.details.about}</p>
                            </div><br />
                            </div>
                            <div className="col-md-3">
                                <h4>Price Starting From:</h4>
                                <div className="text-center text-success"><h6>${hotDeal.chargesPerPerson}</h6></div><br></br>
                                <div><button className="btn btn-primary btn-block book" onClick={() => this.getitenary(hotDeal)}>View Details</button></div><br></br>
                                <div><button className="btn btn-primary btn-block book" onClick={() => this.openBooking(hotDeal)}>Book</button></div>
                            </div>
                        
                    </div>
                </div >
            );
            hotDealsArray.push(element);
        }
        return hotDealsArray;
    }

    componentDidMount() {
        this.getHotDeals();
        this.calculateCharges();
    }
    render() {
        if (this.state.bookingPage) {
            if (sessionStorage.getItem("userName") !== null) {
                return <Redirect to={
                    {
                        pathname: "/book/" + this.state.dealId,
                        state: {
                            noOfPerson: this.state.bookingForm.noOfPerson,
                            date: this.state.bookingForm.date,
                            deal: this.state.deal,
                            flights: this.state.bookingForm.flights
                        }
                    }
                }></Redirect>
            }
            else {
                alert('Please login to continue!')
                this.setState({ bookingPage: false })
                return <Redirect to="/login"></Redirect>
            }
        }
        return (
            <div>
                {this.state.hotDeals.length === 0 ? (
                    <div id="details" className="details-section">
                        <div className="text-center">
                            <ProgressSpinner></ProgressSpinner>
                        </div>
                    </div>) : null}
                <div className="row destination card">
                    {this.displayHotDeals()}
                    <Sidebar visible={this.state.showItinerary} baseZIndex="1" position="right" className="p-sidebar-lg" onHide={(e) => this.setState({ showItinerary: false })}>
                        <h2>{this.state.deal.name}</h2>
                        <TabView activeIndex={Number(this.state.index)} onTabChange={(e) => this.setState({ index: e.index })}>
                            <TabPanel header="Overview">
                                <div className="row text-center">
                                
                                    {this.state.deal ?
                                        <div className="col-md-6 text-center">
                                            <img className="package-image" scr={require("../../public" + this.state.deal.imageUrl)} alt="destination comes here" />
                                        </div> : null}
                                    <div className="col-md-6 text-left">
                                        <h4>Package Includes:</h4>
                                        <ul>
                                            {this.state.showItinerary ? this.displayPackageInlusions() : null}
                                        </ul>
                                    </div>
                                </div>
                                <div className="text-justify itineraryAbout">
                                    <h4>Tour Overview:</h4>
                                    {this.state.deal ? this.state.deal.details.about : null}
                                </div>
                            </TabPanel>


                            <TabPanel header="Itinerary">
                                {this.displayPackageHighlights()}
                                   
                            </TabPanel>

                            <TabPanel header="Book">
                                <h4 className="itenaryAbout text-left">**Charges per Person:Rs.{this.state.deal.chargesPerPerson}</h4>
                                <form className="text-left" onSubmit={this.handleSubmit}>
                                    <div className="form-group">
                                        <label htmlFor="noOfPersons">Number of Travelers:</label>
                                        <input
                                            type="number"
                                            id="noOfPersons"
                                            className="form-control"
                                            name="noOfPerson"
                                            placeholder="min-1 max-5"
                                            value={this.state.bookingForm.noOfPerson}
                                            onChange={this.handleChange}
                                        />

                                        {this.state.bookingFormErrorMessage.noOfPerson ?
                                            <span className="text-danger">{this.state.bookingFormErrorMessage.noOfPerson}</span>
                                            : null}
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="date">Trip start Date:</label>
                                        <input
                                            type="date"
                                            id="date"
                                            className="form-control"
                                            name="date"
                                            value={this.state.bookingForm.date}
                                            onChange={this.handleChange}
                                        />

                                        {this.state.bookingFormErrorMessage.date ?
                                            <span className="text-danger">{this.state.bookingFormErrorMessage.date}</span>
                                            : null}
                                    </div>
                                    <div className="form-group">
                                        <label>Include Flight:</label>&nbsp;
                                        <InputSwitch name="flights" id="flights"
                                            checked={this.state.bookingForm.flight}
                                            onChange={this.handleChange} />
                                    </div>
                                    <div className="form-group">
                                        <button id="buttonCalc" className="btn btn-primary" type="submit" disabled={!this.state.bookingFormValid.buttonActive}>Calculate Charges</button>&nbsp;
                                    </div>
                                </form>
                                {!this.state.totalCharges ?
                                    (
                                        <React.Fragment><div className="text-left">**Charges Exclude flight Charges </div><br></br></React.Fragment>
                                    )
                                    :
                                    (
                                        <h4 className="text-success">
                                            Your Trip Ends On {this.state.checkOutDate} and
                                    Your will pay ${this.state.totalCharges}
                                        </h4>
                                    )
                                }
                                <div className="text-center">
                                    <button disabled={!this.state.bookingFormValid.buttonActive} className="btn btn-primary" onClick={() => this.loadBookingPage(this.state.deal.destinationId)}>Book</button>&nbsp;
                                
                                <button type="button" className="btn btn-primary" onClick={(e) => this.setState({ showItinerary: false })}>Cancel</button>
                                </div>
                            </TabPanel>

                        </TabView>
                    </Sidebar>
                </div>
            </div>

        )
    }
}

export default HotDeals;